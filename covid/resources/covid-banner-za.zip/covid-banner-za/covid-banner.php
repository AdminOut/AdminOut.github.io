<?php
/**
 * Plugin Name: COVID-19 Banner ZA
 * Plugin URI: https://adminout.net
 * Description: Display a COVID-19 banner at the top of your .co.za website.
 * Version: 1.0.0
 * Author: Adminout
 * Author URI: https://adminout.net
 * License: MIT
 *
 * @package COVID-19 Banner ZA
 * @version 1.0.0
 * @author Adminout <info@adminout.net>
 */
define('VERSION', '1.0.0');

add_action('wp_enqueue_scripts', 'covid_banner_za');
function covid_banner_za()
{
    // Enqueue the style
    wp_register_style('covid-banner-style', plugin_dir_url(__FILE__) . 'covid-banner-za.css', '', VERSION);
    wp_enqueue_style('covid-banner-style');

    // Enqueue the script
    wp_register_script('covid-banner-script', plugin_dir_url(__FILE__) . 'covid-banner-za.js', array('jquery'), VERSION, true);
    wp_enqueue_script('covid-banner-script');

}
