=== COVID-19 Banner ZA ===
Contributors: adminout
Tags: covid-19, south africa, banner, .co.za banner
Requires at least: 3.0.1
Tested up to: 5.4.0
Stable tag: 1.0.0
License: MIT
License URI: https://opensource.org/licenses/MIT

Display a COVID-19 Banner ZA/bar at the top of your website.

== Description ==

This plugin makes it easy to display a simple announcement banner or bar at the top of your website. You can easily customize the color of the links, text, and background of the bar from within the settings. You can also customize to your heart's desire by adding your own custom CSS. There's also a fancy preview section within the settings so you can see your changes before you save them.

== Installation ==

= From your WordPress dashboard =

1. Visit 'Plugins > Add New'
2. Search for 'COVID-19 Banner ZA'
3. Activate 'COVID-19 Banner ZA' from your Plugins page.
4. Visit 'COVID-19 Banner ZA' in the sidebar to create a new banner.

= From WordPress.org =

1. Download 'COVID-19 Banner ZA'.
2. Upload the 'covid-banner' directory to your '/wp-content/plugins/' directory, using your favorite method (ftp, sftp, scp, etc...)
3. Activate 'COVID-19 Banner ZA' from your Plugins page.
4. Visit 'COVID-19 Banner ZA' in the sidebar to create a new banner.

= How do I disable the banner? =

Simply deactivate the COVID-19 banner in your plugin menu.


== Changelog ==

= 1.0.0 =
* Initialize project.
